</main>

<footer class="site-footer">
    <p>MiniWiki Blog © <?= date('Y') ?></p>
</footer>

</body>
</html>
